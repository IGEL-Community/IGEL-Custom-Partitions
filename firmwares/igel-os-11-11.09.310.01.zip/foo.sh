#!/bin/bash
#set -x
#trap read debug

zenity --width=$(xdpyinfo | awk '/dimensions/{print $2}'|cut -f1 -dx) --height=$(xdpyinfo | awk '/dimensions/{print $2}'|cut -f2 -dx) --text-info \6 --filename="/wfs/EULA.txt" --ok-label=Accept --cancel-label=Refuse --title="Please read the End-User License Agreement carefully before proceeding."

if [ $? = 0 ]; then
  echo "EULA!"
else
  echo "EULA Refused"
  exit 1
fi

